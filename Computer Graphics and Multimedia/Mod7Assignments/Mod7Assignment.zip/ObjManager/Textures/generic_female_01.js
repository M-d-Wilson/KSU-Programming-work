var generic_female_01 = `
# 
# 
newmtl generic_female_01
Ns 96.078431
Ka 0.000000 0.000000 0.000000
Kd 0.640000 0.640000 0.640000
Ks 0.050000 0.050000 0.050000
Ni 1.000000
d 1.000000
illum 2
map_Kd generic_female01_d.png

`;