var harleen_quinzel = `
# 
# 

newmtl Harlee_QuinzelHairHelmet
Ns 96.078431
Ka 0.000000 0.000000 0.000000
Kd 0.640000 0.640000 0.640000
Ks 0.000000 0.000000 0.000000
Ni 1.000000
d 1.000000
illum 1
map_Kd Harleen_Quinzel_HairHelmet_D.png

newmtl HarleenQuinzelEarings
Ns 96.078431
Ka 0.000000 0.000000 0.000000
Kd 0.640000 0.640000 0.640000
Ks 0.000000 0.000000 0.000000
Ni 1.000000
d 1.000000
illum 1
map_Kd Harleen_Quinzel_Torso_D.png

newmtl HarleenQuinzelEye
Ns 96.078431
Ka 0.000000 0.000000 0.000000
Kd 0.640000 0.640000 0.640000
Ks 0.000000 0.000000 0.000000
Ni 1.000000
d 1.000000
illum 1
map_Kd Harleen_Quinzel_Eye_D.png

newmtl HarleenQuinzelGlass
Ns 96.078431
Ka 0.000000 0.000000 0.000000
Kd 0.640000 0.640000 0.640000
Ks 0.100000 0.100000 0.100000
Ni 1.000000
d 0.000000
illum 2
map_Kd Harleen_Quinzel_Glass_D.png

newmtl HarleenQuinzelHair
Ns 96.078431
Ka 0.000000 0.000000 0.000000
Kd 0.640000 0.640000 0.640000
Ks 0.000000 0.000000 0.000000
Ni 1.000000
d 0.000000
illum 1
map_Kd Harleen_Quinzel_Hair_D.png

newmtl HarleenQuinzelHead
Ns 96.078431
Ka 0.000000 0.000000 0.000000
Kd 0.640000 0.640000 0.640000
Ks 0.000000 0.000000 0.000000
Ni 1.000000
d 1.000000
illum 1
map_Kd Harleen_Quinzel_Head_D.png

newmtl HarleenQuinzelLegs
Ns 96.078431
Ka 0.000000 0.000000 0.000000
Kd 0.640000 0.640000 0.640000
Ks 0.000000 0.000000 0.000000
Ni 1.000000
d 1.000000
illum 1
map_Kd Harleen_Quinzel_Legs_D.png

newmtl HarleenQuinzelTorso
Ns 96.078431
Ka 0.000000 0.000000 0.000000
Kd 0.640000 0.640000 0.640000
Ks 0.000000 0.000000 0.000000
Ni 1.000000
d 1.000000
illum 1
map_Kd Harleen_Quinzel_Torso_D.png
`;