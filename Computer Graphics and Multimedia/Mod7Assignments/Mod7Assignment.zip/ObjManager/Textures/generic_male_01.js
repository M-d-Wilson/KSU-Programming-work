var generic_male_01 = `
# 
# 
newmtl generic_male_01
Ns 37.254902
Ka 0.000000 0.000000 0.000000
Kd 0.640000 0.640000 0.640000
Ks 0.050000 0.050000 0.050000
Ni 1.000000
d 1.000000
illum 2
map_Kd generic_male01_d.png

`;