var batman = `
newmtl Batman_V3_Eyes_MIC
illum 4
Kd 0.00 0.00 0.00
Ka 0.00 0.00 0.00
Tf 1.00 1.00 1.00
map_Kd Batman_V3_Eye_High_D.png
Ni 1.00
Ks 0.50 0.50 0.50
Ns 18.00
newmtl Batman_Year1_Body_MAT
illum 4
Kd 0.00 0.00 0.00
Ka 0.00 0.00 0.00
Tf 1.00 1.00 1.00
map_Kd Batman_Torso_D.png
Ni 1.00
newmtl Batman_Year1_Legs
illum 4
Kd 0.00 0.00 0.00
Ka 0.00 0.00 0.00
Tf 1.00 1.00 1.00
map_Kd Batman_Legs_D.png
Ni 1.00
newmtl Batman_Year1_MAT
illum 4
Kd 0.00 0.00 0.00
Ka 0.00 0.00 0.00
Tf 1.00 1.00 1.00
map_Kd batman_head_D.png
Ni 1.00
newmtl DLC1_Batman_Earth_Cape_MIC
illum 4
Kd 0.00 0.00 0.00
Ka 0.00 0.00 0.00
Tf 1.00 1.00 1.00
map_Kd Batman_Cape_D.png
Ni 1.00
Ks 0.50 0.50 0.50
Ns 18.00
`;